<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Menu_model extends CI_Model {




    
    public function consultar_enlaces($arrDatos) {

    }
    
 
    
}
?>