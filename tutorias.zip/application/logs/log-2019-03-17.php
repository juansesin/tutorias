<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-17 06:12:04 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-17 19:07:43 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
