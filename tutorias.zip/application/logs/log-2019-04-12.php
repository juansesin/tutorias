<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-12 18:28:09 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
