<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-25 19:56:36 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-25 19:58:07 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-25 20:01:24 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-25 20:01:30 --> Severity: Notice --> Undefined index: asistencia /home/bmottag/public_html/tutorias/application/modules/tutorias/views/listado_inscritos.php 172
ERROR - 2019-03-25 20:01:30 --> Severity: Notice --> Undefined variable: clase /home/bmottag/public_html/tutorias/application/modules/tutorias/views/listado_inscritos.php 184
ERROR - 2019-03-25 20:01:30 --> Severity: Notice --> Undefined variable: valor /home/bmottag/public_html/tutorias/application/modules/tutorias/views/listado_inscritos.php 184
ERROR - 2019-03-25 20:01:30 --> Severity: Notice --> Undefined variable: estado /home/bmottag/public_html/tutorias/application/modules/tutorias/views/listado_inscritos.php 191
