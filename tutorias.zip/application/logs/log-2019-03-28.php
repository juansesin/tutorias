<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-28 07:37:30 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 07:38:40 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 07:42:10 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 07:42:53 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 07:49:13 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 07:57:43 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 07:59:10 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 08:12:53 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 08:13:27 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 08:13:45 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 08:14:22 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 08:16:51 --> Severity: Notice --> Undefined variable: listaTemas /home/bmottag/public_html/tutorias/application/modules/tutorias/views/form_modificar.php 112
ERROR - 2019-03-28 08:50:25 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 08:52:20 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 08:52:35 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 08:53:27 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 08:56:52 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 08:59:49 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 09:00:27 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 09:01:33 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 09:02:20 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 10:11:05 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 10:20:33 --> Severity: Notice --> Undefined variable: listaTemas /home/bmottag/public_html/tutorias/application/modules/tutorias/views/form_modificar.php 112
ERROR - 2019-03-28 10:20:49 --> Severity: Notice --> Undefined variable: listaTemas /home/bmottag/public_html/tutorias/application/modules/tutorias/views/form_modificar.php 112
ERROR - 2019-03-28 10:23:03 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 10:23:17 --> Severity: Notice --> Undefined variable: listaTemas /home/bmottag/public_html/tutorias/application/modules/tutorias/views/form_modificar.php 112
ERROR - 2019-03-28 10:28:53 --> Severity: Notice --> Undefined variable: listaTemas /home/bmottag/public_html/tutorias/application/modules/tutorias/views/form_modificar.php 112
ERROR - 2019-03-28 10:29:15 --> Severity: Notice --> Undefined variable: listaTemas /home/bmottag/public_html/tutorias/application/modules/tutorias/views/form_modificar.php 112
ERROR - 2019-03-28 10:30:14 --> Severity: Notice --> Undefined variable: listaTemas /home/bmottag/public_html/tutorias/application/modules/tutorias/views/form_modificar.php 112
ERROR - 2019-03-28 10:35:13 --> Severity: Notice --> Undefined variable: listaTemas /home/bmottag/public_html/tutorias/application/modules/tutorias/views/form_modificar.php 112
ERROR - 2019-03-28 10:35:16 --> Severity: Notice --> Undefined variable: lista /home/bmottag/public_html/tutorias/application/modules/tutorias/views/form_modificar.php 78
ERROR - 2019-03-28 10:35:16 --> Severity: Notice --> Undefined variable: lista /home/bmottag/public_html/tutorias/application/modules/tutorias/views/form_modificar.php 85
ERROR - 2019-03-28 10:35:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/bmottag/public_html/tutorias/application/modules/tutorias/views/form_modificar.php 89
ERROR - 2019-03-28 10:35:16 --> Severity: Notice --> Undefined variable: lista /home/bmottag/public_html/tutorias/application/modules/tutorias/views/form_modificar.php 96
ERROR - 2019-03-28 10:36:24 --> Severity: Notice --> Undefined variable: lista /home/bmottag/public_html/tutorias/application/modules/tutorias/views/form_modificar.php 85
ERROR - 2019-03-28 10:36:24 --> Severity: Warning --> Invalid argument supplied for foreach() /home/bmottag/public_html/tutorias/application/modules/tutorias/views/form_modificar.php 89
ERROR - 2019-03-28 10:36:26 --> Severity: Notice --> Undefined variable: lista /home/bmottag/public_html/tutorias/application/modules/tutorias/views/form_modificar.php 85
ERROR - 2019-03-28 10:36:26 --> Severity: Warning --> Invalid argument supplied for foreach() /home/bmottag/public_html/tutorias/application/modules/tutorias/views/form_modificar.php 89
ERROR - 2019-03-28 10:36:56 --> Severity: Notice --> Undefined variable: lista /home/bmottag/public_html/tutorias/application/modules/tutorias/views/form_modificar.php 85
ERROR - 2019-03-28 10:36:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/bmottag/public_html/tutorias/application/modules/tutorias/views/form_modificar.php 89
ERROR - 2019-03-28 10:36:59 --> Severity: Notice --> Undefined variable: lista /home/bmottag/public_html/tutorias/application/modules/tutorias/views/form_modificar.php 85
ERROR - 2019-03-28 10:36:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/bmottag/public_html/tutorias/application/modules/tutorias/views/form_modificar.php 89
ERROR - 2019-03-28 10:36:59 --> Severity: Notice --> Undefined variable: lista /home/bmottag/public_html/tutorias/application/modules/tutorias/views/form_modificar.php 85
ERROR - 2019-03-28 10:36:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/bmottag/public_html/tutorias/application/modules/tutorias/views/form_modificar.php 89
ERROR - 2019-03-28 10:41:57 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 10:43:25 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 10:44:20 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 10:46:23 --> 404 Page Not Found: /index
ERROR - 2019-03-28 10:46:30 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 10:47:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/bmottag/public_html/tutorias/application/modules/tutorias/views/listado_inscritos.php 167
ERROR - 2019-03-28 10:47:43 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 10:47:52 --> 404 Page Not Found: ../modules/tutorias/controllers/Tutorias/index
ERROR - 2019-03-28 10:47:59 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 10:48:14 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 10:49:22 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 10:51:30 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 10:55:40 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 10:56:38 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 10:57:16 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 10:58:26 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 10:59:23 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 11:02:59 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 11:03:38 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 11:04:49 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 11:04:57 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 11:18:05 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 11:24:41 --> Severity: Warning --> Missing argument 1 for pr(), called in /home/bmottag/public_html/tutorias/application/modules/docente/controllers/Docente.php on line 85 and defined /home/bmottag/public_html/tutorias/application/helpers/funciones_helper.php 12
ERROR - 2019-03-28 11:24:41 --> Severity: Notice --> Undefined variable: objVar /home/bmottag/public_html/tutorias/application/helpers/funciones_helper.php 14
ERROR - 2019-03-28 11:24:41 --> Severity: Notice --> Undefined variable: objVar /home/bmottag/public_html/tutorias/application/helpers/funciones_helper.php 14
ERROR - 2019-03-28 11:24:41 --> Severity: Notice --> Undefined variable: objVar /home/bmottag/public_html/tutorias/application/helpers/funciones_helper.php 19
ERROR - 2019-03-28 11:42:58 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 11:57:09 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 11:57:14 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 11:57:19 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 11:59:22 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 12:32:31 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 13:12:25 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 13:13:09 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 13:13:42 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 13:14:17 --> Query error: Unknown column 'W.calificacion_texto' in 'field list' - Invalid query: SELECT `T`.*, `D`.`NOMBRE`, `L`.`direccion`, `H`.`hora` `minimo`, `H`.`formato_24` `formato_minimo`, `X`.`hora` `maximo`, `Y`.`asignaturas`, `Z`.`temas`, `W`.`calificacion_texto`, `W`.`calificacion`, `W`.`id_tutorias_estudiante`
FROM `tutorias_estudiante` `W`
INNER JOIN `tutorias_principal` `T` ON `T`.`id_tutorias_principal` = `W`.`fk_te_id_tutorias_principal`
INNER JOIN `docente` `D` ON `D`.`ID_DOCENTE` = `T`.`fk_id_docente`
INNER JOIN `param_lugares` `L` ON `L`.`id_param_lugares` = `T`.`fk_id_lugar`
INNER JOIN `param_horas` `H` ON `H`.`id_hora` = `T`.`hora_inicio`
INNER JOIN `param_horas` `X` ON `X`.`id_hora` = `T`.`hora_fin`
LEFT JOIN `param_asignaturas` `Y` ON `Y`.`id_param_asignaturas` = `T`.`fk_tp_id_param_asignaturas`
LEFT JOIN `param_temas` `Z` ON `Z`.`id_param_temas` = `T`.`fk_tp_id_param_temas`
WHERE `W`.`fk_te_id_user` = '2'
ORDER BY `fecha_tutoria` DESC
ERROR - 2019-03-28 13:14:17 --> Severity: error --> Exception: Call to a member function num_rows() on boolean /home/servic/public_html/tutorias/application/models/General_model.php 378
ERROR - 2019-03-28 13:14:39 --> Query error: Unknown column 'W.calificacion_texto' in 'field list' - Invalid query: SELECT `T`.*, `D`.`NOMBRE`, `L`.`direccion`, `H`.`hora` `minimo`, `H`.`formato_24` `formato_minimo`, `X`.`hora` `maximo`, `Y`.`asignaturas`, `Z`.`temas`, `W`.`calificacion_texto`, `W`.`calificacion`, `W`.`id_tutorias_estudiante`
FROM `tutorias_estudiante` `W`
INNER JOIN `tutorias_principal` `T` ON `T`.`id_tutorias_principal` = `W`.`fk_te_id_tutorias_principal`
INNER JOIN `docente` `D` ON `D`.`ID_DOCENTE` = `T`.`fk_id_docente`
INNER JOIN `param_lugares` `L` ON `L`.`id_param_lugares` = `T`.`fk_id_lugar`
INNER JOIN `param_horas` `H` ON `H`.`id_hora` = `T`.`hora_inicio`
INNER JOIN `param_horas` `X` ON `X`.`id_hora` = `T`.`hora_fin`
LEFT JOIN `param_asignaturas` `Y` ON `Y`.`id_param_asignaturas` = `T`.`fk_tp_id_param_asignaturas`
LEFT JOIN `param_temas` `Z` ON `Z`.`id_param_temas` = `T`.`fk_tp_id_param_temas`
WHERE `W`.`fk_te_id_user` = '2'
ORDER BY `fecha_tutoria` DESC
ERROR - 2019-03-28 13:14:39 --> Severity: error --> Exception: Call to a member function num_rows() on boolean /home/servic/public_html/tutorias/application/models/General_model.php 378
ERROR - 2019-03-28 13:15:39 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 13:15:41 --> Query error: Unknown column 'W.calificacion_texto' in 'field list' - Invalid query: SELECT `T`.*, `D`.`NOMBRE`, `L`.`direccion`, `H`.`hora` `minimo`, `H`.`formato_24` `formato_minimo`, `X`.`hora` `maximo`, `Y`.`asignaturas`, `Z`.`temas`, `W`.`calificacion_texto`, `W`.`calificacion`, `W`.`id_tutorias_estudiante`
FROM `tutorias_estudiante` `W`
INNER JOIN `tutorias_principal` `T` ON `T`.`id_tutorias_principal` = `W`.`fk_te_id_tutorias_principal`
INNER JOIN `docente` `D` ON `D`.`ID_DOCENTE` = `T`.`fk_id_docente`
INNER JOIN `param_lugares` `L` ON `L`.`id_param_lugares` = `T`.`fk_id_lugar`
INNER JOIN `param_horas` `H` ON `H`.`id_hora` = `T`.`hora_inicio`
INNER JOIN `param_horas` `X` ON `X`.`id_hora` = `T`.`hora_fin`
LEFT JOIN `param_asignaturas` `Y` ON `Y`.`id_param_asignaturas` = `T`.`fk_tp_id_param_asignaturas`
LEFT JOIN `param_temas` `Z` ON `Z`.`id_param_temas` = `T`.`fk_tp_id_param_temas`
WHERE `W`.`fk_te_id_user` = '2'
ORDER BY `fecha_tutoria` DESC
ERROR - 2019-03-28 13:15:41 --> Severity: error --> Exception: Call to a member function num_rows() on boolean /home/servic/public_html/tutorias/application/models/General_model.php 378
ERROR - 2019-03-28 13:15:44 --> Query error: Unknown column 'W.calificacion_texto' in 'field list' - Invalid query: SELECT `T`.*, `D`.`NOMBRE`, `L`.`direccion`, `H`.`hora` `minimo`, `H`.`formato_24` `formato_minimo`, `X`.`hora` `maximo`, `Y`.`asignaturas`, `Z`.`temas`, `W`.`calificacion_texto`, `W`.`calificacion`, `W`.`id_tutorias_estudiante`
FROM `tutorias_estudiante` `W`
INNER JOIN `tutorias_principal` `T` ON `T`.`id_tutorias_principal` = `W`.`fk_te_id_tutorias_principal`
INNER JOIN `docente` `D` ON `D`.`ID_DOCENTE` = `T`.`fk_id_docente`
INNER JOIN `param_lugares` `L` ON `L`.`id_param_lugares` = `T`.`fk_id_lugar`
INNER JOIN `param_horas` `H` ON `H`.`id_hora` = `T`.`hora_inicio`
INNER JOIN `param_horas` `X` ON `X`.`id_hora` = `T`.`hora_fin`
LEFT JOIN `param_asignaturas` `Y` ON `Y`.`id_param_asignaturas` = `T`.`fk_tp_id_param_asignaturas`
LEFT JOIN `param_temas` `Z` ON `Z`.`id_param_temas` = `T`.`fk_tp_id_param_temas`
WHERE `W`.`fk_te_id_user` = '2'
ORDER BY `fecha_tutoria` DESC
ERROR - 2019-03-28 13:15:44 --> Severity: error --> Exception: Call to a member function num_rows() on boolean /home/servic/public_html/tutorias/application/models/General_model.php 378
ERROR - 2019-03-28 13:15:55 --> Query error: Unknown column 'W.calificacion_texto' in 'field list' - Invalid query: SELECT `T`.*, `D`.`NOMBRE`, `L`.`direccion`, `H`.`hora` `minimo`, `H`.`formato_24` `formato_minimo`, `X`.`hora` `maximo`, `Y`.`asignaturas`, `Z`.`temas`, `W`.`calificacion_texto`, `W`.`calificacion`, `W`.`id_tutorias_estudiante`
FROM `tutorias_estudiante` `W`
INNER JOIN `tutorias_principal` `T` ON `T`.`id_tutorias_principal` = `W`.`fk_te_id_tutorias_principal`
INNER JOIN `docente` `D` ON `D`.`ID_DOCENTE` = `T`.`fk_id_docente`
INNER JOIN `param_lugares` `L` ON `L`.`id_param_lugares` = `T`.`fk_id_lugar`
INNER JOIN `param_horas` `H` ON `H`.`id_hora` = `T`.`hora_inicio`
INNER JOIN `param_horas` `X` ON `X`.`id_hora` = `T`.`hora_fin`
LEFT JOIN `param_asignaturas` `Y` ON `Y`.`id_param_asignaturas` = `T`.`fk_tp_id_param_asignaturas`
LEFT JOIN `param_temas` `Z` ON `Z`.`id_param_temas` = `T`.`fk_tp_id_param_temas`
WHERE `W`.`fk_te_id_user` = '2'
ORDER BY `fecha_tutoria` DESC
ERROR - 2019-03-28 13:15:55 --> Severity: error --> Exception: Call to a member function num_rows() on boolean /home/servic/public_html/tutorias/application/models/General_model.php 378
ERROR - 2019-03-28 13:15:57 --> Query error: Unknown column 'W.calificacion_texto' in 'field list' - Invalid query: SELECT `T`.*, `D`.`NOMBRE`, `L`.`direccion`, `H`.`hora` `minimo`, `H`.`formato_24` `formato_minimo`, `X`.`hora` `maximo`, `Y`.`asignaturas`, `Z`.`temas`, `W`.`calificacion_texto`, `W`.`calificacion`, `W`.`id_tutorias_estudiante`
FROM `tutorias_estudiante` `W`
INNER JOIN `tutorias_principal` `T` ON `T`.`id_tutorias_principal` = `W`.`fk_te_id_tutorias_principal`
INNER JOIN `docente` `D` ON `D`.`ID_DOCENTE` = `T`.`fk_id_docente`
INNER JOIN `param_lugares` `L` ON `L`.`id_param_lugares` = `T`.`fk_id_lugar`
INNER JOIN `param_horas` `H` ON `H`.`id_hora` = `T`.`hora_inicio`
INNER JOIN `param_horas` `X` ON `X`.`id_hora` = `T`.`hora_fin`
LEFT JOIN `param_asignaturas` `Y` ON `Y`.`id_param_asignaturas` = `T`.`fk_tp_id_param_asignaturas`
LEFT JOIN `param_temas` `Z` ON `Z`.`id_param_temas` = `T`.`fk_tp_id_param_temas`
WHERE `W`.`fk_te_id_user` = '2'
ORDER BY `fecha_tutoria` DESC
ERROR - 2019-03-28 13:15:57 --> Severity: error --> Exception: Call to a member function num_rows() on boolean /home/servic/public_html/tutorias/application/models/General_model.php 378
ERROR - 2019-03-28 13:16:29 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 13:17:23 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 13:18:10 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 13:20:54 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 13:20:56 --> Query error: Unknown column 'W.calificacion_texto' in 'field list' - Invalid query: SELECT `T`.*, `D`.`NOMBRE`, `L`.`direccion`, `H`.`hora` `minimo`, `H`.`formato_24` `formato_minimo`, `X`.`hora` `maximo`, `Y`.`asignaturas`, `Z`.`temas`, `W`.`calificacion_texto`, `W`.`calificacion`, `W`.`id_tutorias_estudiante`
FROM `tutorias_estudiante` `W`
INNER JOIN `tutorias_principal` `T` ON `T`.`id_tutorias_principal` = `W`.`fk_te_id_tutorias_principal`
INNER JOIN `docente` `D` ON `D`.`ID_DOCENTE` = `T`.`fk_id_docente`
INNER JOIN `param_lugares` `L` ON `L`.`id_param_lugares` = `T`.`fk_id_lugar`
INNER JOIN `param_horas` `H` ON `H`.`id_hora` = `T`.`hora_inicio`
INNER JOIN `param_horas` `X` ON `X`.`id_hora` = `T`.`hora_fin`
LEFT JOIN `param_asignaturas` `Y` ON `Y`.`id_param_asignaturas` = `T`.`fk_tp_id_param_asignaturas`
LEFT JOIN `param_temas` `Z` ON `Z`.`id_param_temas` = `T`.`fk_tp_id_param_temas`
WHERE `W`.`fk_te_id_user` = '2'
ORDER BY `fecha_tutoria` DESC
ERROR - 2019-03-28 13:20:56 --> Severity: error --> Exception: Call to a member function num_rows() on boolean /home/servic/public_html/tutorias/application/models/General_model.php 378
ERROR - 2019-03-28 13:21:15 --> Query error: Unknown column 'W.calificacion_texto' in 'field list' - Invalid query: SELECT `T`.*, `D`.`NOMBRE`, `L`.`direccion`, `H`.`hora` `minimo`, `H`.`formato_24` `formato_minimo`, `X`.`hora` `maximo`, `Y`.`asignaturas`, `Z`.`temas`, `W`.`calificacion_texto`, `W`.`calificacion`, `W`.`id_tutorias_estudiante`
FROM `tutorias_estudiante` `W`
INNER JOIN `tutorias_principal` `T` ON `T`.`id_tutorias_principal` = `W`.`fk_te_id_tutorias_principal`
INNER JOIN `docente` `D` ON `D`.`ID_DOCENTE` = `T`.`fk_id_docente`
INNER JOIN `param_lugares` `L` ON `L`.`id_param_lugares` = `T`.`fk_id_lugar`
INNER JOIN `param_horas` `H` ON `H`.`id_hora` = `T`.`hora_inicio`
INNER JOIN `param_horas` `X` ON `X`.`id_hora` = `T`.`hora_fin`
LEFT JOIN `param_asignaturas` `Y` ON `Y`.`id_param_asignaturas` = `T`.`fk_tp_id_param_asignaturas`
LEFT JOIN `param_temas` `Z` ON `Z`.`id_param_temas` = `T`.`fk_tp_id_param_temas`
WHERE `W`.`fk_te_id_user` = '2'
ORDER BY `fecha_tutoria` DESC
ERROR - 2019-03-28 13:21:15 --> Severity: error --> Exception: Call to a member function num_rows() on boolean /home/servic/public_html/tutorias/application/models/General_model.php 378
ERROR - 2019-03-28 13:23:46 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 13:24:30 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 13:25:15 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 13:27:43 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 13:27:59 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 13:28:02 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 13:29:10 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 13:29:23 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 13:29:27 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 13:29:45 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 13:32:16 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 13:32:18 --> Query error: Unknown column 'W.calificacion_texto' in 'field list' - Invalid query: SELECT `T`.*, `D`.`NOMBRE`, `L`.`direccion`, `H`.`hora` `minimo`, `H`.`formato_24` `formato_minimo`, `X`.`hora` `maximo`, `Y`.`asignaturas`, `Z`.`temas`, `W`.`calificacion_texto`, `W`.`calificacion`, `W`.`id_tutorias_estudiante`
FROM `tutorias_estudiante` `W`
INNER JOIN `tutorias_principal` `T` ON `T`.`id_tutorias_principal` = `W`.`fk_te_id_tutorias_principal`
INNER JOIN `docente` `D` ON `D`.`ID_DOCENTE` = `T`.`fk_id_docente`
INNER JOIN `param_lugares` `L` ON `L`.`id_param_lugares` = `T`.`fk_id_lugar`
INNER JOIN `param_horas` `H` ON `H`.`id_hora` = `T`.`hora_inicio`
INNER JOIN `param_horas` `X` ON `X`.`id_hora` = `T`.`hora_fin`
LEFT JOIN `param_asignaturas` `Y` ON `Y`.`id_param_asignaturas` = `T`.`fk_tp_id_param_asignaturas`
LEFT JOIN `param_temas` `Z` ON `Z`.`id_param_temas` = `T`.`fk_tp_id_param_temas`
WHERE `W`.`fk_te_id_user` = '2'
ORDER BY `fecha_tutoria` DESC
ERROR - 2019-03-28 13:32:18 --> Severity: error --> Exception: Call to a member function num_rows() on boolean /home/servic/public_html/tutorias/application/models/General_model.php 378
ERROR - 2019-03-28 14:31:07 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 14:42:48 --> 404 Page Not Found: ../modules/tutorias/controllers/Tutorias/index
ERROR - 2019-03-28 15:00:43 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 15:02:21 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 15:02:57 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 22:06:29 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 22:06:55 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-28 22:07:26 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
