<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-03 06:18:47 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-03 06:19:33 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-03 06:44:00 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-03 07:59:36 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-03 09:00:14 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-03 09:00:20 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-03 09:23:41 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-03 09:24:14 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-03 10:15:49 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-03 11:02:33 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file /home/servic/public_html/tutorias/application/modules/parametros/controllers/Parametros.php 379
ERROR - 2019-04-03 11:03:13 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) /home/servic/public_html/tutorias/application/modules/parametros/controllers/Parametros.php 375
ERROR - 2019-04-03 11:08:14 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-03 12:36:44 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'servic_tutorias'@'localhost' (using password: YES) C:\xampp\htdocs\tutorias\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2019-04-03 12:36:44 --> Unable to connect to the database
ERROR - 2019-04-03 12:36:44 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'servic_tutorias'@'localhost' (using password: YES) C:\xampp\htdocs\tutorias\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2019-04-03 12:36:44 --> Unable to connect to the database
ERROR - 2019-04-03 12:36:44 --> 404 Page Not Found: /index
ERROR - 2019-04-03 12:38:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'servic_tutorias'@'localhost' (using password: YES) C:\xampp\htdocs\tutorias\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2019-04-03 12:38:20 --> Unable to connect to the database
ERROR - 2019-04-03 12:38:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'servic_tutorias'@'localhost' (using password: YES) C:\xampp\htdocs\tutorias\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2019-04-03 12:38:20 --> Unable to connect to the database
ERROR - 2019-04-03 12:38:20 --> 404 Page Not Found: /index
ERROR - 2019-04-03 12:40:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'servic_tutorias'@'localhost' (using password: YES) C:\xampp\htdocs\tutorias\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2019-04-03 12:40:00 --> Unable to connect to the database
ERROR - 2019-04-03 12:40:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'servic_tutorias'@'localhost' (using password: YES) C:\xampp\htdocs\tutorias\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2019-04-03 12:40:00 --> Unable to connect to the database
ERROR - 2019-04-03 12:40:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'servic_tutorias'@'localhost' (using password: YES) C:\xampp\htdocs\tutorias\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2019-04-03 12:40:00 --> Unable to connect to the database
ERROR - 2019-04-03 12:40:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'servic_tutorias'@'localhost' (using password: YES) C:\xampp\htdocs\tutorias\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2019-04-03 12:40:00 --> Unable to connect to the database
ERROR - 2019-04-03 12:40:00 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 12:40:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'servic_tutorias'@'localhost' (using password: YES) C:\xampp\htdocs\tutorias\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2019-04-03 12:40:00 --> Unable to connect to the database
ERROR - 2019-04-03 12:40:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'servic_tutorias'@'localhost' (using password: YES) C:\xampp\htdocs\tutorias\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2019-04-03 12:40:00 --> Unable to connect to the database
ERROR - 2019-04-03 12:40:41 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'servic_tutorias'@'localhost' (using password: YES) C:\xampp\htdocs\tutorias\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2019-04-03 12:40:41 --> Unable to connect to the database
ERROR - 2019-04-03 12:40:41 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'servic_tutorias'@'localhost' (using password: YES) C:\xampp\htdocs\tutorias\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2019-04-03 12:40:41 --> Unable to connect to the database
ERROR - 2019-04-03 12:40:41 --> Severity: error --> Exception: Call to a member function real_escape_string() on boolean C:\xampp\htdocs\tutorias\system\database\drivers\mysqli\mysqli_driver.php 392
ERROR - 2019-04-03 12:40:45 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'servic_tutorias'@'localhost' (using password: YES) C:\xampp\htdocs\tutorias\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2019-04-03 12:40:45 --> Unable to connect to the database
ERROR - 2019-04-03 12:40:45 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'servic_tutorias'@'localhost' (using password: YES) C:\xampp\htdocs\tutorias\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2019-04-03 12:40:45 --> Unable to connect to the database
ERROR - 2019-04-03 13:54:35 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 13:54:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 13:54:43 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 13:54:43 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 13:54:54 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 13:54:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 13:55:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 13:55:20 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 13:55:20 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 13:55:38 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 13:55:38 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 13:55:44 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 13:55:45 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 13:55:53 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 13:55:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 13:56:57 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 13:56:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 13:59:23 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 13:59:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 13:59:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 13:59:48 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 13:59:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 14:00:08 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 14:00:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 14:10:37 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 14:10:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 14:11:24 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 14:11:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 14:12:06 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 14:12:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 14:14:18 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 14:14:18 --> 404 Page Not Found: ../modules/tutorias/controllers/Tutorias/dashboard
ERROR - 2019-04-03 14:14:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 14:14:41 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 14:14:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 14:19:13 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 14:19:14 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 14:20:23 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 14:20:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 14:20:35 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 14:20:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 14:21:01 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 14:21:01 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 14:24:40 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 14:24:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 14:37:38 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 14:37:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 14:38:59 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 14:38:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 14:46:35 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 14:46:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 14:46:52 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 14:46:52 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 14:47:51 --> Severity: Notice --> Undefined index: photo C:\xampp\htdocs\tutorias\application\modules\login\controllers\Login.php 57
ERROR - 2019-04-03 14:47:51 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 14:48:22 --> Severity: error --> Exception: Call to undefined method Login_model::validateLogin() C:\xampp\htdocs\tutorias\application\modules\login\controllers\Login.php 45
ERROR - 2019-04-03 14:48:45 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 94
ERROR - 2019-04-03 14:48:45 --> Severity: Compile Warning --> Unterminated comment starting line 49 C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 49
ERROR - 2019-04-03 14:48:50 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 94
ERROR - 2019-04-03 14:48:50 --> Severity: Compile Warning --> Unterminated comment starting line 49 C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 49
ERROR - 2019-04-03 14:49:07 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 95
ERROR - 2019-04-03 14:49:13 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 95
ERROR - 2019-04-03 14:49:34 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 14:49:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 14:49:56 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 14:49:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 14:52:01 --> 404 Page Not Found: ../modules/login/controllers/Login/validateUser
ERROR - 2019-04-03 14:52:53 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 14:52:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 15:11:11 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 15:11:11 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 15:11:34 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 95
ERROR - 2019-04-03 15:11:59 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 15:11:59 --> Severity: error --> Exception: Call to undefined method Login_model::redireccionarUsuario() C:\xampp\htdocs\tutorias\application\modules\login\controllers\Login.php 63
ERROR - 2019-04-03 15:12:08 --> 404 Page Not Found: ../modules/login/controllers/Login/dashboard
ERROR - 2019-04-03 15:12:18 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 15:12:51 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 15:12:51 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 15:13:07 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 15:13:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 15:13:49 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 15:13:49 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 15:14:27 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 15:14:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 15:14:42 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 15:14:58 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 15:14:58 --> 404 Page Not Found: ../modules/tutorias/controllers/Tutorias/dashboard
ERROR - 2019-04-03 15:15:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 15:15:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 15:15:41 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 15:15:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 15:16:11 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 15:16:11 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 15:17:01 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 15:17:01 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 15:17:27 --> Severity: Notice --> Undefined variable: sql C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 25
ERROR - 2019-04-03 15:17:27 --> Severity: Warning --> mysqli::query(): Empty query C:\xampp\htdocs\tutorias\system\database\drivers\mysqli\mysqli_driver.php 306
ERROR - 2019-04-03 15:17:27 --> Query error:  - Invalid query: 
ERROR - 2019-04-03 15:17:27 --> Severity: error --> Exception: Call to a member function num_rows() on boolean C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 27
ERROR - 2019-04-03 15:18:05 --> Severity: Notice --> Undefined variable: query C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 27
ERROR - 2019-04-03 15:18:05 --> Severity: error --> Exception: Call to a member function num_rows() on null C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 27
ERROR - 2019-04-03 15:18:36 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 15:18:36 --> Severity: Notice --> Undefined variable: state C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 62
ERROR - 2019-04-03 15:18:36 --> 404 Page Not Found: /index
ERROR - 2019-04-03 15:19:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 15:19:26 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 15:19:26 --> Severity: Notice --> Undefined variable: state C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 65
ERROR - 2019-04-03 15:19:26 --> Severity: Notice --> Undefined variable: state C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 74
ERROR - 2019-04-03 15:25:21 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\tutorias\application\models\General_model.php 19
ERROR - 2019-04-03 15:25:21 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\tutorias\application\models\General_model.php 20
ERROR - 2019-04-03 15:28:12 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 15:28:12 --> Severity: Notice --> Undefined variable: state C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 65
ERROR - 2019-04-03 15:28:12 --> Severity: Notice --> Undefined variable: state C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 74
ERROR - 2019-04-03 15:29:00 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 15:29:00 --> Severity: Notice --> Undefined variable: state C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 65
ERROR - 2019-04-03 15:29:00 --> Severity: Notice --> Undefined variable: state C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 74
ERROR - 2019-04-03 15:30:48 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 15:30:48 --> Severity: Notice --> Undefined variable: state C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 65
ERROR - 2019-04-03 15:30:48 --> Severity: Notice --> Undefined variable: state C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 74
ERROR - 2019-04-03 15:31:13 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 15:31:13 --> Severity: Notice --> Undefined variable: state C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 65
ERROR - 2019-04-03 15:31:13 --> Severity: Notice --> Undefined variable: state C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 74
ERROR - 2019-04-03 15:31:45 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
