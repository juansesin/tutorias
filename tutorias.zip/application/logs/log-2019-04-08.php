<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-08 09:36:36 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
