<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-19 15:08:48 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-03-19 15:19:49 --> Severity: Notice --> Undefined variable: msj /home/bmottag/public_html/tutorias/application/modules/tutorias/controllers/Tutorias.php 172
