<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-17 08:23:41 --> 404 Page Not Found: /index
ERROR - 2019-04-17 08:23:55 --> 404 Page Not Found: /index
ERROR - 2019-04-17 08:24:03 --> 404 Page Not Found: /index
ERROR - 2019-04-17 08:24:08 --> 404 Page Not Found: /index
ERROR - 2019-04-17 08:24:34 --> 404 Page Not Found: ../modules/tutorias/controllers/Tutorias/index.php
ERROR - 2019-04-17 08:24:39 --> 404 Page Not Found: ../modules/tutorias/controllers/Tutorias/index.php
ERROR - 2019-04-17 08:24:41 --> 404 Page Not Found: ../modules/tutorias/controllers/Tutorias/index.php
ERROR - 2019-04-17 08:24:41 --> 404 Page Not Found: ../modules/tutorias/controllers/Tutorias/index.php
ERROR - 2019-04-17 08:25:08 --> 404 Page Not Found: ../modules/tutorias/controllers/Tutorias/index.php
ERROR - 2019-04-17 08:26:42 --> 404 Page Not Found: /index
ERROR - 2019-04-17 08:29:04 --> 404 Page Not Found: ../modules/tutorias/controllers/Tutorias/index.php
ERROR - 2019-04-17 08:31:12 --> 404 Page Not Found: ../modules/tutorias/controllers/Tutorias/index.php
ERROR - 2019-04-17 08:35:21 --> 404 Page Not Found: ../modules/tutorias/controllers/Tutorias/index.php
ERROR - 2019-04-17 08:35:26 --> 404 Page Not Found: ../modules/tutorias/controllers/Tutorias/index.php
ERROR - 2019-04-17 08:59:11 --> 404 Page Not Found: ../modules/tutorias/controllers/Tutorias/index.php
ERROR - 2019-04-17 09:08:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-17 09:08:49 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-17 09:08:49 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tutorias\application\hooks\Home.php 58
