<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-15 21:07:26 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-15 22:15:12 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
