<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-02 14:18:32 --> 404 Page Not Found: /index
ERROR - 2019-04-02 14:19:01 --> 404 Page Not Found: /index
ERROR - 2019-04-02 14:19:05 --> 404 Page Not Found: /index
ERROR - 2019-04-02 14:19:12 --> 404 Page Not Found: ../modules/login/controllers/Login/tutorias
ERROR - 2019-04-02 14:19:22 --> 404 Page Not Found: /index
ERROR - 2019-04-02 14:42:31 --> 404 Page Not Found: /index
ERROR - 2019-04-02 14:53:14 --> 404 Page Not Found: /index
ERROR - 2019-04-02 17:11:26 --> 404 Page Not Found: /index
ERROR - 2019-04-02 20:47:46 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-02 20:50:43 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
