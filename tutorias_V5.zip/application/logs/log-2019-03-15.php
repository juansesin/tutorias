<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-15 08:44:11 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
