<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-20 10:34:12 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-20 10:34:14 --> 404 Page Not Found: /index
ERROR - 2019-04-20 10:34:14 --> 404 Page Not Found: /index
ERROR - 2019-04-20 10:34:15 --> 404 Page Not Found: /index
ERROR - 2019-04-20 10:34:15 --> 404 Page Not Found: /index
