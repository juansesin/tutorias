<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-21 09:30:51 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 09:30:52 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 09:30:52 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 09:30:53 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 09:30:53 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 09:33:47 --> Severity: error --> Exception: syntax error, unexpected '.' /home/servic/public_html/tutorias/application/models/General_model.php 19
ERROR - 2019-04-21 09:34:17 --> Severity: error --> Exception: syntax error, unexpected '.' /home/servic/public_html/tutorias/application/models/General_model.php 19
ERROR - 2019-04-21 09:35:33 --> Severity: error --> Exception: syntax error, unexpected '.' /home/servic/public_html/tutorias/application/models/General_model.php 19
ERROR - 2019-04-21 09:35:37 --> Severity: error --> Exception: syntax error, unexpected '.' /home/servic/public_html/tutorias/application/models/General_model.php 19
ERROR - 2019-04-21 09:38:23 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 09:38:24 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 09:38:24 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 09:38:24 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 09:50:53 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 09:50:53 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 09:50:54 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 09:50:54 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 09:51:38 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 09:51:38 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 09:51:38 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 09:51:38 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 09:56:14 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 09:56:14 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 09:56:14 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 09:56:14 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 09:56:28 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 09:56:28 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 09:56:29 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 09:56:29 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 09:58:43 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 09:58:43 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 09:58:44 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 09:58:44 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 09:59:17 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 09:59:17 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 09:59:18 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 09:59:18 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 09:59:52 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 09:59:52 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 09:59:53 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 09:59:53 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:04:18 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:04:18 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:04:20 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:04:20 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:12:03 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:12:04 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:12:04 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:12:04 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:12:59 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:12:59 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:13:00 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:13:00 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:14:06 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:14:06 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:14:08 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:14:08 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:14:54 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:14:54 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:14:54 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:14:54 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:16:13 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:16:13 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:16:13 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:16:13 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:16:41 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:16:41 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:16:42 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:16:42 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:17:33 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:17:33 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:17:36 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:17:36 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:18:23 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:18:23 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:18:24 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:18:24 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:20:33 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:20:33 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:20:34 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:20:34 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:21:25 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:21:25 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:32:39 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:32:39 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:32:40 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:32:40 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:37:44 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:37:44 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:37:45 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:37:45 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:41:04 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:41:04 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:41:04 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:41:04 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:41:12 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:41:12 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:41:13 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:41:13 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:42:28 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:42:28 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:42:29 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:42:29 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:43:39 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:43:39 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:43:39 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:43:39 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:44:57 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:44:57 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:44:57 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:44:57 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:46:11 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:46:11 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:46:11 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:46:11 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:46:38 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:46:38 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:46:39 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:46:39 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:49:14 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:49:14 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:49:15 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:49:15 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:57:28 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:57:28 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:57:28 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:57:28 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:59:53 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:59:53 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:59:53 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 10:59:53 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:08:42 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:08:42 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:08:42 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:08:42 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:18:53 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:18:53 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:18:54 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:18:54 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:19:59 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:19:59 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:21:01 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:21:01 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:21:02 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:21:02 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:22:23 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:22:23 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:22:23 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:22:23 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:23:26 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:23:27 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:23:54 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:23:54 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:23:55 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:23:55 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:25:18 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:25:18 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:25:19 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:25:19 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:25:52 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:25:52 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:26:25 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:26:26 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:26:26 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:26:26 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:27:06 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:27:06 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:27:06 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:27:07 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:28:15 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 11:28:16 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:28:17 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:28:46 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:28:46 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:30:48 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 11:34:34 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/vendor
ERROR - 2019-04-21 11:34:34 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/vendor
ERROR - 2019-04-21 11:38:51 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/vendor
ERROR - 2019-04-21 11:38:51 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/vendor
ERROR - 2019-04-21 11:39:08 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/vendor
ERROR - 2019-04-21 11:39:08 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/vendor
ERROR - 2019-04-21 11:40:06 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/vendor
ERROR - 2019-04-21 11:40:06 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/vendor
ERROR - 2019-04-21 11:41:12 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/vendor
ERROR - 2019-04-21 11:41:12 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/vendor
ERROR - 2019-04-21 11:42:52 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 11:42:53 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:42:53 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:45:14 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 11:46:44 --> 404 Page Not Found: /index
ERROR - 2019-04-21 11:46:44 --> 404 Page Not Found: /index
ERROR - 2019-04-21 11:46:48 --> 404 Page Not Found: /index
ERROR - 2019-04-21 11:46:48 --> 404 Page Not Found: /index
ERROR - 2019-04-21 11:47:12 --> 404 Page Not Found: /index
ERROR - 2019-04-21 11:47:13 --> 404 Page Not Found: /index
ERROR - 2019-04-21 11:47:31 --> 404 Page Not Found: /index
ERROR - 2019-04-21 11:47:31 --> 404 Page Not Found: /index
ERROR - 2019-04-21 11:47:51 --> 404 Page Not Found: /index
ERROR - 2019-04-21 11:47:51 --> 404 Page Not Found: /index
ERROR - 2019-04-21 11:48:05 --> 404 Page Not Found: /index
ERROR - 2019-04-21 11:48:05 --> 404 Page Not Found: /index
ERROR - 2019-04-21 11:48:46 --> 404 Page Not Found: /index
ERROR - 2019-04-21 11:48:46 --> 404 Page Not Found: /index
ERROR - 2019-04-21 11:48:47 --> 404 Page Not Found: /index
ERROR - 2019-04-21 11:48:48 --> 404 Page Not Found: /index
ERROR - 2019-04-21 11:49:55 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 11:49:56 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:49:56 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:50:45 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:50:45 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:50:46 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:50:46 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:55:34 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:55:34 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:55:35 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:55:35 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:55:45 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:55:45 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:56:33 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:56:33 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:57:57 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:57:57 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:58:53 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/buscar
ERROR - 2019-04-21 11:59:03 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:59:03 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:59:22 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 11:59:22 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 12:02:36 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 12:02:36 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 12:02:37 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 12:02:37 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 12:03:07 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 12:03:07 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 12:03:59 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 12:03:59 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 12:03:59 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 12:03:59 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 12:08:33 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 12:08:33 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 12:08:33 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 12:08:33 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 12:22:51 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 12:22:51 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 12:23:03 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 12:23:03 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 12:44:42 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 12:44:42 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 12:44:42 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 12:44:42 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 12:44:54 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 12:44:55 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:44:55 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:47:16 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:47:16 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:47:21 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:47:21 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:47:35 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:47:35 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:47:35 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:47:37 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:47:37 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:47:44 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:47:44 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:47:44 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:47:47 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:47:47 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:47:47 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:48:20 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:48:20 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:48:21 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:48:22 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:48:24 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:48:24 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:49:03 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:49:03 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:49:05 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:49:05 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:49:47 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:49:47 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:49:48 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:49:48 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:51:03 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:51:03 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:51:04 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:51:04 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:51:58 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:51:58 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:52:01 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:52:01 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:52:13 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:52:13 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:52:14 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:52:14 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:54:05 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:54:05 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:54:06 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:54:06 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:54:15 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:54:15 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:54:16 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:54:16 --> 404 Page Not Found: /index
ERROR - 2019-04-21 12:54:57 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 12:54:58 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 12:54:58 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 12:55:50 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 12:55:51 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 12:55:51 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 12:55:51 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 12:58:48 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 12:58:48 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 12:58:48 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 12:58:48 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 13:07:07 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 13:07:07 --> Severity: Notice --> Undefined variable: ESCUELA /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 74
ERROR - 2019-04-21 13:07:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 74
ERROR - 2019-04-21 13:07:07 --> Severity: Notice --> Undefined variable: DOCENTE /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 88
ERROR - 2019-04-21 13:07:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 88
ERROR - 2019-04-21 13:07:07 --> Severity: Notice --> Undefined variable: ASIGNATURA /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 101
ERROR - 2019-04-21 13:07:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 101
ERROR - 2019-04-21 13:07:08 --> 404 Page Not Found: /index
ERROR - 2019-04-21 13:07:08 --> 404 Page Not Found: /index
ERROR - 2019-04-21 13:08:09 --> Severity: Notice --> Undefined variable: ESCUELA /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 74
ERROR - 2019-04-21 13:08:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 74
ERROR - 2019-04-21 13:08:09 --> Severity: Notice --> Undefined variable: DOCENTE /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 88
ERROR - 2019-04-21 13:08:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 88
ERROR - 2019-04-21 13:08:09 --> Severity: Notice --> Undefined variable: ASIGNATURA /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 101
ERROR - 2019-04-21 13:08:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 101
ERROR - 2019-04-21 13:08:10 --> 404 Page Not Found: /index
ERROR - 2019-04-21 13:08:10 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:00:02 --> Severity: Notice --> Undefined variable: ESCUELA /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 73
ERROR - 2019-04-21 14:00:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 73
ERROR - 2019-04-21 14:00:02 --> Severity: Notice --> Undefined variable: DOCENTE /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 86
ERROR - 2019-04-21 14:00:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 86
ERROR - 2019-04-21 14:00:02 --> Severity: Notice --> Undefined variable: ASIGNATURA /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 99
ERROR - 2019-04-21 14:00:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 99
ERROR - 2019-04-21 14:00:06 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:00:06 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:00:25 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:00:25 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:00:37 --> Severity: Notice --> Undefined variable: ESCUELA /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 73
ERROR - 2019-04-21 14:00:37 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 73
ERROR - 2019-04-21 14:00:37 --> Severity: Notice --> Undefined variable: DOCENTE /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 86
ERROR - 2019-04-21 14:00:37 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 86
ERROR - 2019-04-21 14:00:37 --> Severity: Notice --> Undefined variable: ASIGNATURA /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 99
ERROR - 2019-04-21 14:00:37 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 99
ERROR - 2019-04-21 14:00:37 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:00:37 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:01:27 --> Severity: Notice --> Undefined variable: ESCUELA /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 73
ERROR - 2019-04-21 14:01:27 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 73
ERROR - 2019-04-21 14:01:27 --> Severity: Notice --> Undefined variable: DOCENTE /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 86
ERROR - 2019-04-21 14:01:27 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 86
ERROR - 2019-04-21 14:01:27 --> Severity: Notice --> Undefined variable: ASIGNATURA /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 99
ERROR - 2019-04-21 14:01:27 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 99
ERROR - 2019-04-21 14:01:28 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:01:28 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:02:34 --> Severity: Notice --> Undefined variable: ESCUELA /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 73
ERROR - 2019-04-21 14:02:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 73
ERROR - 2019-04-21 14:02:34 --> Severity: Notice --> Undefined variable: DOCENTE /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 86
ERROR - 2019-04-21 14:02:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 86
ERROR - 2019-04-21 14:02:34 --> Severity: Notice --> Undefined variable: ASIGNATURA /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 99
ERROR - 2019-04-21 14:02:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 99
ERROR - 2019-04-21 14:02:35 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:02:35 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:04:30 --> Severity: Notice --> Undefined variable: ESCUELA /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 73
ERROR - 2019-04-21 14:04:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 73
ERROR - 2019-04-21 14:04:30 --> Severity: Notice --> Undefined variable: DOCENTE /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 86
ERROR - 2019-04-21 14:04:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 86
ERROR - 2019-04-21 14:04:30 --> Severity: Notice --> Undefined variable: ASIGNATURA /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 99
ERROR - 2019-04-21 14:04:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 99
ERROR - 2019-04-21 14:04:31 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:04:31 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:04:37 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:04:37 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:04:59 --> Severity: Notice --> Undefined variable: ESCUELA /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 73
ERROR - 2019-04-21 14:04:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 73
ERROR - 2019-04-21 14:04:59 --> Severity: Notice --> Undefined variable: DOCENTE /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 86
ERROR - 2019-04-21 14:04:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 86
ERROR - 2019-04-21 14:04:59 --> Severity: Notice --> Undefined variable: ASIGNATURA /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 99
ERROR - 2019-04-21 14:04:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 99
ERROR - 2019-04-21 14:05:00 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:05:00 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:05:09 --> Severity: Notice --> Undefined variable: ESCUELA /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 73
ERROR - 2019-04-21 14:05:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 73
ERROR - 2019-04-21 14:05:09 --> Severity: Notice --> Undefined variable: DOCENTE /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 86
ERROR - 2019-04-21 14:05:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 86
ERROR - 2019-04-21 14:05:09 --> Severity: Notice --> Undefined variable: ASIGNATURA /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 99
ERROR - 2019-04-21 14:05:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 99
ERROR - 2019-04-21 14:05:09 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:05:09 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:05:10 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:05:28 --> Severity: Notice --> Undefined variable: ESCUELA /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 73
ERROR - 2019-04-21 14:05:28 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 73
ERROR - 2019-04-21 14:05:28 --> Severity: Notice --> Undefined variable: DOCENTE /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 86
ERROR - 2019-04-21 14:05:28 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 86
ERROR - 2019-04-21 14:05:28 --> Severity: Notice --> Undefined variable: ASIGNATURA /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 99
ERROR - 2019-04-21 14:05:28 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 99
ERROR - 2019-04-21 14:05:28 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:05:29 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:08:16 --> Severity: Notice --> Undefined variable: ESCUELA /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 73
ERROR - 2019-04-21 14:08:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 73
ERROR - 2019-04-21 14:08:16 --> Severity: Notice --> Undefined variable: DOCENTE /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 86
ERROR - 2019-04-21 14:08:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 86
ERROR - 2019-04-21 14:08:16 --> Severity: Notice --> Undefined variable: ASIGNATURA /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 99
ERROR - 2019-04-21 14:08:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 99
ERROR - 2019-04-21 14:08:16 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:08:16 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:10:47 --> Severity: Notice --> Undefined variable: ESCUELA /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 73
ERROR - 2019-04-21 14:10:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 73
ERROR - 2019-04-21 14:10:47 --> Severity: Notice --> Undefined variable: DOCENTE /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 86
ERROR - 2019-04-21 14:10:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 86
ERROR - 2019-04-21 14:10:47 --> Severity: Notice --> Undefined variable: ASIGNATURA /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 99
ERROR - 2019-04-21 14:10:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 99
ERROR - 2019-04-21 14:10:50 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:10:50 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:10:52 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:10:52 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:12:14 --> Severity: Notice --> Undefined variable: ESCUELA /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 73
ERROR - 2019-04-21 14:12:14 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 73
ERROR - 2019-04-21 14:12:14 --> Severity: Notice --> Undefined variable: DOCENTE /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 86
ERROR - 2019-04-21 14:12:14 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 86
ERROR - 2019-04-21 14:12:14 --> Severity: Notice --> Undefined variable: ASIGNATURA /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 99
ERROR - 2019-04-21 14:12:14 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 99
ERROR - 2019-04-21 14:12:15 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:12:15 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:12:17 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:12:17 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:12:35 --> Severity: Notice --> Undefined variable: ESCUELA /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 73
ERROR - 2019-04-21 14:12:35 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 73
ERROR - 2019-04-21 14:12:35 --> Severity: Notice --> Undefined variable: DOCENTE /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 86
ERROR - 2019-04-21 14:12:35 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 86
ERROR - 2019-04-21 14:12:35 --> Severity: Notice --> Undefined variable: ASIGNATURA /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 99
ERROR - 2019-04-21 14:12:35 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 99
ERROR - 2019-04-21 14:12:36 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:12:36 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:12:38 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:12:38 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:13:31 --> Severity: Notice --> Undefined variable: ESCUELA /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 73
ERROR - 2019-04-21 14:13:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 73
ERROR - 2019-04-21 14:13:31 --> Severity: Notice --> Undefined variable: DOCENTE /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 86
ERROR - 2019-04-21 14:13:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 86
ERROR - 2019-04-21 14:13:31 --> Severity: Notice --> Undefined variable: ASIGNATURA /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 99
ERROR - 2019-04-21 14:13:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 99
ERROR - 2019-04-21 14:13:32 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:13:32 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:13:34 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:13:34 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:14:12 --> Severity: Notice --> Undefined variable: ESCUELA /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 73
ERROR - 2019-04-21 14:14:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 73
ERROR - 2019-04-21 14:14:12 --> Severity: Notice --> Undefined variable: DOCENTE /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 86
ERROR - 2019-04-21 14:14:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 86
ERROR - 2019-04-21 14:14:12 --> Severity: Notice --> Undefined variable: ASIGNATURA /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 99
ERROR - 2019-04-21 14:14:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 99
ERROR - 2019-04-21 14:14:13 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:14:13 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:14:19 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:14:19 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:16:20 --> Severity: Notice --> Undefined variable: ESCUELA /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 73
ERROR - 2019-04-21 14:16:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 73
ERROR - 2019-04-21 14:16:20 --> Severity: Notice --> Undefined variable: DOCENTE /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 86
ERROR - 2019-04-21 14:16:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 86
ERROR - 2019-04-21 14:16:20 --> Severity: Notice --> Undefined variable: ASIGNATURA /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 99
ERROR - 2019-04-21 14:16:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 99
ERROR - 2019-04-21 14:16:23 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:16:23 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:16:24 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:16:24 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:24:16 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:24:17 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:24:27 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:24:27 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:25:14 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:25:14 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:29:11 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:29:11 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:29:40 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:29:40 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:31:32 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:31:32 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:33:03 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:33:04 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:33:35 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:33:35 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:37:51 --> Severity: Notice --> Undefined variable: infoTutorias /home/servic/public_html/tutorias/application/modules/dashboard/views/form_busqueda_admin.php 189
ERROR - 2019-04-21 14:37:52 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:37:52 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:38:14 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:38:14 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:38:14 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:38:14 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:41:46 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 14:41:48 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:41:48 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:42:06 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:42:06 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:42:32 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:42:33 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:43:44 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:43:44 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:43:45 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:48:22 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 14:48:23 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:48:23 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:48:43 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:48:43 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:49:06 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:49:06 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:49:06 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:49:33 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:49:33 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:49:33 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:50:49 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:50:49 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:51:52 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 14:51:53 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:51:53 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:52:46 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:52:46 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:54:17 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:54:17 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:54:36 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:54:36 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:55:17 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:55:18 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:55:22 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:55:22 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:55:45 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:55:45 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:58:12 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:58:12 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:59:29 --> 404 Page Not Found: /index
ERROR - 2019-04-21 14:59:30 --> 404 Page Not Found: /index
ERROR - 2019-04-21 15:07:36 --> 404 Page Not Found: /index
ERROR - 2019-04-21 15:07:36 --> 404 Page Not Found: /index
ERROR - 2019-04-21 15:08:11 --> 404 Page Not Found: /index
ERROR - 2019-04-21 15:08:11 --> 404 Page Not Found: /index
ERROR - 2019-04-21 15:33:06 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) /home/servic/public_html/tutorias/application/modules/tutorias/controllers/Tutorias.php 486
ERROR - 2019-04-21 15:34:04 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) /home/servic/public_html/tutorias/application/modules/tutorias/controllers/Tutorias.php 482
ERROR - 2019-04-21 15:36:43 --> 404 Page Not Found: /index
ERROR - 2019-04-21 15:36:43 --> 404 Page Not Found: /index
ERROR - 2019-04-21 15:44:40 --> 404 Page Not Found: /index
ERROR - 2019-04-21 15:44:40 --> 404 Page Not Found: /index
ERROR - 2019-04-21 15:45:10 --> 404 Page Not Found: /index
ERROR - 2019-04-21 15:45:11 --> 404 Page Not Found: /index
ERROR - 2019-04-21 15:46:39 --> 404 Page Not Found: /index
ERROR - 2019-04-21 15:46:39 --> 404 Page Not Found: /index
ERROR - 2019-04-21 15:46:53 --> 404 Page Not Found: /index
ERROR - 2019-04-21 15:46:54 --> 404 Page Not Found: /index
ERROR - 2019-04-21 15:47:10 --> 404 Page Not Found: /index
ERROR - 2019-04-21 15:47:10 --> 404 Page Not Found: /index
ERROR - 2019-04-21 15:49:47 --> 404 Page Not Found: /index
ERROR - 2019-04-21 15:49:47 --> 404 Page Not Found: /index
ERROR - 2019-04-21 15:49:54 --> 404 Page Not Found: /index
ERROR - 2019-04-21 15:49:55 --> 404 Page Not Found: /index
ERROR - 2019-04-21 15:50:02 --> 404 Page Not Found: /index
ERROR - 2019-04-21 15:50:03 --> 404 Page Not Found: /index
ERROR - 2019-04-21 15:51:49 --> 404 Page Not Found: /index
ERROR - 2019-04-21 15:51:49 --> 404 Page Not Found: /index
ERROR - 2019-04-21 15:51:49 --> 404 Page Not Found: /index
ERROR - 2019-04-21 15:52:04 --> 404 Page Not Found: /index
ERROR - 2019-04-21 15:52:04 --> 404 Page Not Found: /index
ERROR - 2019-04-21 15:53:17 --> 404 Page Not Found: /index
ERROR - 2019-04-21 15:53:20 --> 404 Page Not Found: /index
ERROR - 2019-04-21 15:53:25 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:00:47 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 16:00:48 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:00:48 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:01:07 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:01:07 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:07:39 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 16:07:41 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:07:41 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:07:42 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:07:42 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:07:53 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:07:53 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:08:08 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:08:10 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:08:14 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:08:16 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:08:31 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:08:31 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:09:00 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:09:01 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:09:04 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:09:04 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:09:20 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 16:09:21 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:09:21 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:09:26 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:09:26 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:10:41 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 16:10:44 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:10:44 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:11:01 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:11:01 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:11:22 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:11:22 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:11:31 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:11:31 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:13:21 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:13:21 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:13:21 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:13:38 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:13:38 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:13:49 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:13:49 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:14:02 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:14:02 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:14:38 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:14:38 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:14:39 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:14:39 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:14:50 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:14:50 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:16:32 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 16:16:33 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 16:16:33 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 16:16:46 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 16:16:46 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 16:16:46 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 16:37:24 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 16:37:25 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:37:25 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:45:45 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:45:45 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:45:52 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:45:52 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:46:05 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:46:05 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:46:16 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:46:16 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:46:21 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:46:21 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:46:57 --> 404 Page Not Found: /index
ERROR - 2019-04-21 16:46:58 --> 404 Page Not Found: /index
ERROR - 2019-04-21 17:01:55 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 17:01:56 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 17:01:56 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 17:02:18 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 17:02:19 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 17:02:19 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 17:02:39 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 17:02:39 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 17:02:39 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 17:02:58 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 17:02:59 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 17:02:59 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 17:03:19 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 17:03:20 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 17:03:20 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 17:04:18 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 17:04:18 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 17:04:18 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 17:07:33 --> Severity: error --> Exception: syntax error, unexpected '}' /home/servic/public_html/tutorias/application/modules/estudiante/views/listado_tutorias_inscrito.php 130
ERROR - 2019-04-21 17:10:36 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 17:10:37 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 17:10:37 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 17:11:16 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 17:11:17 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 17:11:17 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 17:11:38 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 17:11:39 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 17:11:39 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 17:18:52 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 17:18:53 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 17:18:53 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 17:20:18 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 17:20:18 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 17:20:18 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 17:21:38 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 17:21:39 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 17:21:39 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 18:45:32 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 18:45:33 --> 404 Page Not Found: /index
ERROR - 2019-04-21 18:45:33 --> 404 Page Not Found: /index
ERROR - 2019-04-21 18:46:47 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 18:46:47 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 18:46:47 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 19:14:09 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 19:14:09 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 19:14:41 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 19:14:41 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 19:15:30 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 19:15:30 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 19:15:59 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 19:16:00 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 19:16:00 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 19:16:22 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 19:16:22 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 19:16:49 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 19:16:49 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 19:17:11 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 19:17:13 --> 404 Page Not Found: /index
ERROR - 2019-04-21 19:17:13 --> 404 Page Not Found: /index
ERROR - 2019-04-21 19:17:40 --> 404 Page Not Found: /index
ERROR - 2019-04-21 19:17:40 --> 404 Page Not Found: /index
ERROR - 2019-04-21 19:18:11 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 19:18:12 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 19:18:12 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 19:22:47 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 19:22:48 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 19:22:48 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 19:23:05 --> Severity: error --> Exception: syntax error, unexpected '}' /home/servic/public_html/tutorias/application/modules/estudiante/views/listado_tutorias.php 164
ERROR - 2019-04-21 19:28:48 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 19:28:48 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 19:32:09 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 19:32:09 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 19:54:32 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 19:54:33 --> 404 Page Not Found: /index
ERROR - 2019-04-21 19:54:33 --> 404 Page Not Found: /index
ERROR - 2019-04-21 20:01:33 --> 404 Page Not Found: /index
ERROR - 2019-04-21 20:01:33 --> 404 Page Not Found: /index
ERROR - 2019-04-21 20:01:46 --> 404 Page Not Found: ../modules/tutorias/controllers/Tutorias/vendor
ERROR - 2019-04-21 20:01:46 --> 404 Page Not Found: ../modules/tutorias/controllers/Tutorias/vendor
ERROR - 2019-04-21 20:02:42 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 20:02:44 --> 404 Page Not Found: /index
ERROR - 2019-04-21 20:02:44 --> 404 Page Not Found: /index
ERROR - 2019-04-21 20:02:54 --> 404 Page Not Found: ../modules/tutorias/controllers/Tutorias/vendor
ERROR - 2019-04-21 20:02:54 --> 404 Page Not Found: ../modules/tutorias/controllers/Tutorias/vendor
ERROR - 2019-04-21 20:02:54 --> 404 Page Not Found: ../modules/tutorias/controllers/Tutorias/vendor
ERROR - 2019-04-21 20:04:39 --> 404 Page Not Found: ../modules/tutorias/controllers/Tutorias/vendor
ERROR - 2019-04-21 20:04:39 --> 404 Page Not Found: ../modules/tutorias/controllers/Tutorias/vendor
ERROR - 2019-04-21 20:04:43 --> 404 Page Not Found: ../modules/tutorias/controllers/Tutorias/vendor
ERROR - 2019-04-21 20:04:43 --> 404 Page Not Found: ../modules/tutorias/controllers/Tutorias/vendor
ERROR - 2019-04-21 20:05:44 --> 404 Page Not Found: ../modules/tutorias/controllers/Tutorias/vendor
ERROR - 2019-04-21 20:05:44 --> 404 Page Not Found: ../modules/tutorias/controllers/Tutorias/vendor
ERROR - 2019-04-21 20:05:45 --> 404 Page Not Found: ../modules/tutorias/controllers/Tutorias/vendor
ERROR - 2019-04-21 20:05:45 --> 404 Page Not Found: ../modules/tutorias/controllers/Tutorias/vendor
ERROR - 2019-04-21 20:06:33 --> 404 Page Not Found: ../modules/tutorias/controllers/Tutorias/vendor
ERROR - 2019-04-21 20:06:33 --> 404 Page Not Found: ../modules/tutorias/controllers/Tutorias/vendor
ERROR - 2019-04-21 20:06:34 --> 404 Page Not Found: ../modules/tutorias/controllers/Tutorias/vendor
ERROR - 2019-04-21 20:06:34 --> 404 Page Not Found: ../modules/tutorias/controllers/Tutorias/vendor
ERROR - 2019-04-21 20:09:22 --> 404 Page Not Found: ../modules/tutorias/controllers/Tutorias/vendor
ERROR - 2019-04-21 20:09:22 --> 404 Page Not Found: ../modules/tutorias/controllers/Tutorias/vendor
ERROR - 2019-04-21 20:09:23 --> 404 Page Not Found: ../modules/tutorias/controllers/Tutorias/vendor
ERROR - 2019-04-21 20:09:23 --> 404 Page Not Found: ../modules/tutorias/controllers/Tutorias/vendor
ERROR - 2019-04-21 20:13:28 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/vendor
ERROR - 2019-04-21 20:13:28 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/vendor
ERROR - 2019-04-21 20:14:01 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/vendor
ERROR - 2019-04-21 20:14:01 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/vendor
ERROR - 2019-04-21 20:15:35 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/vendor
ERROR - 2019-04-21 20:15:35 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/vendor
ERROR - 2019-04-21 20:15:44 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/vendor
ERROR - 2019-04-21 20:15:44 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/vendor
ERROR - 2019-04-21 20:15:47 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/vendor
ERROR - 2019-04-21 20:15:47 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/vendor
ERROR - 2019-04-21 20:16:09 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/vendor
ERROR - 2019-04-21 20:16:10 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/vendor
ERROR - 2019-04-21 20:17:43 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/vendor
ERROR - 2019-04-21 20:17:43 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/vendor
ERROR - 2019-04-21 20:18:01 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/vendor
ERROR - 2019-04-21 20:18:01 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/vendor
ERROR - 2019-04-21 20:18:34 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/vendor
ERROR - 2019-04-21 20:18:34 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/vendor
ERROR - 2019-04-21 20:21:54 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 20:21:55 --> 404 Page Not Found: /index
ERROR - 2019-04-21 20:21:55 --> 404 Page Not Found: /index
ERROR - 2019-04-21 20:24:09 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 20:24:10 --> 404 Page Not Found: /index
ERROR - 2019-04-21 20:24:10 --> 404 Page Not Found: /index
ERROR - 2019-04-21 20:24:40 --> 404 Page Not Found: /index
ERROR - 2019-04-21 20:28:50 --> 404 Page Not Found: /index
ERROR - 2019-04-21 20:28:50 --> 404 Page Not Found: /index
ERROR - 2019-04-21 20:49:43 --> 404 Page Not Found: /index
ERROR - 2019-04-21 20:49:44 --> 404 Page Not Found: /index
ERROR - 2019-04-21 20:49:46 --> 404 Page Not Found: /index
ERROR - 2019-04-21 20:49:46 --> 404 Page Not Found: /index
ERROR - 2019-04-21 20:49:58 --> 404 Page Not Found: /index
ERROR - 2019-04-21 20:53:28 --> 404 Page Not Found: /index
ERROR - 2019-04-21 20:53:29 --> 404 Page Not Found: /index
ERROR - 2019-04-21 20:53:29 --> 404 Page Not Found: /index
ERROR - 2019-04-21 20:53:30 --> 404 Page Not Found: /index
ERROR - 2019-04-21 20:54:04 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 20:54:05 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 20:54:05 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 20:54:52 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 20:54:53 --> 404 Page Not Found: /index
ERROR - 2019-04-21 20:54:53 --> 404 Page Not Found: /index
ERROR - 2019-04-21 20:55:59 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 20:56:00 --> 404 Page Not Found: /index
ERROR - 2019-04-21 20:56:00 --> 404 Page Not Found: /index
ERROR - 2019-04-21 20:57:28 --> 404 Page Not Found: /index
ERROR - 2019-04-21 20:57:28 --> 404 Page Not Found: /index
ERROR - 2019-04-21 20:59:36 --> 404 Page Not Found: /index
ERROR - 2019-04-21 20:59:37 --> 404 Page Not Found: /index
ERROR - 2019-04-21 20:59:39 --> 404 Page Not Found: /index
ERROR - 2019-04-21 20:59:39 --> 404 Page Not Found: /index
ERROR - 2019-04-21 21:00:05 --> 404 Page Not Found: /index
ERROR - 2019-04-21 21:00:06 --> 404 Page Not Found: /index
ERROR - 2019-04-21 21:00:07 --> 404 Page Not Found: /index
ERROR - 2019-04-21 21:00:08 --> 404 Page Not Found: /index
ERROR - 2019-04-21 21:00:39 --> 404 Page Not Found: /index
ERROR - 2019-04-21 21:00:41 --> 404 Page Not Found: /index
ERROR - 2019-04-21 21:00:42 --> 404 Page Not Found: /index
ERROR - 2019-04-21 21:00:42 --> 404 Page Not Found: /index
ERROR - 2019-04-21 21:01:19 --> 404 Page Not Found: /index
ERROR - 2019-04-21 21:01:20 --> 404 Page Not Found: /index
ERROR - 2019-04-21 21:01:41 --> 404 Page Not Found: /index
ERROR - 2019-04-21 21:01:41 --> 404 Page Not Found: /index
ERROR - 2019-04-21 21:11:22 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 21:11:23 --> 404 Page Not Found: /index
ERROR - 2019-04-21 21:11:23 --> 404 Page Not Found: /index
ERROR - 2019-04-21 21:11:33 --> 404 Page Not Found: /index
ERROR - 2019-04-21 21:11:33 --> 404 Page Not Found: /index
ERROR - 2019-04-21 21:11:46 --> 404 Page Not Found: /index
ERROR - 2019-04-21 21:11:46 --> 404 Page Not Found: /index
ERROR - 2019-04-21 21:14:49 --> 404 Page Not Found: /index
ERROR - 2019-04-21 21:14:49 --> 404 Page Not Found: /index
ERROR - 2019-04-21 21:16:37 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 21:16:38 --> 404 Page Not Found: /index
ERROR - 2019-04-21 21:16:38 --> 404 Page Not Found: /index
ERROR - 2019-04-21 21:17:42 --> 404 Page Not Found: /index
ERROR - 2019-04-21 21:17:42 --> 404 Page Not Found: /index
ERROR - 2019-04-21 21:17:48 --> 404 Page Not Found: /index
ERROR - 2019-04-21 21:17:48 --> 404 Page Not Found: /index
ERROR - 2019-04-21 21:19:09 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 21:19:10 --> 404 Page Not Found: /index
ERROR - 2019-04-21 21:19:11 --> 404 Page Not Found: /index
ERROR - 2019-04-21 21:19:17 --> 404 Page Not Found: /index
ERROR - 2019-04-21 21:19:17 --> 404 Page Not Found: /index
ERROR - 2019-04-21 21:24:39 --> Severity: error --> Exception: syntax error, unexpected end of file /home/servic/public_html/tutorias/application/models/General_model.php 227
ERROR - 2019-04-21 21:25:38 --> 404 Page Not Found: /index
ERROR - 2019-04-21 21:25:38 --> 404 Page Not Found: /index
ERROR - 2019-04-21 21:25:55 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 21:25:55 --> 404 Page Not Found: /index
ERROR - 2019-04-21 21:25:56 --> 404 Page Not Found: /index
ERROR - 2019-04-21 21:26:01 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 21:26:02 --> 404 Page Not Found: /index
ERROR - 2019-04-21 21:26:02 --> 404 Page Not Found: /index
ERROR - 2019-04-21 21:27:33 --> 404 Page Not Found: /index
ERROR - 2019-04-21 21:27:33 --> 404 Page Not Found: /index
ERROR - 2019-04-21 21:27:51 --> 404 Page Not Found: /index
ERROR - 2019-04-21 21:27:51 --> 404 Page Not Found: /index
ERROR - 2019-04-21 21:37:58 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 21:37:59 --> 404 Page Not Found: /index
ERROR - 2019-04-21 21:37:59 --> 404 Page Not Found: /index
ERROR - 2019-04-21 21:37:59 --> 404 Page Not Found: /index
ERROR - 2019-04-21 21:37:59 --> 404 Page Not Found: /index
ERROR - 2019-04-21 21:38:08 --> 404 Page Not Found: /index
ERROR - 2019-04-21 21:38:08 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:01:05 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:01:05 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:01:23 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 22:01:23 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:01:23 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:01:23 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:01:24 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:01:32 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:01:32 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:21:15 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 22:21:16 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:21:16 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:22:12 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 22:22:12 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:22:12 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:23:30 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 22:23:31 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:23:31 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:31:18 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 22:31:18 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:31:18 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:31:30 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:31:30 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:31:46 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:31:46 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:31:55 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 22:31:56 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:31:56 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:32:05 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:32:05 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:33:01 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 22:33:02 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:33:02 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:33:14 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:33:14 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:34:08 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 22:34:09 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:34:09 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:34:13 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:34:13 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:34:24 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:34:24 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:36:05 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:36:05 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:36:05 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:36:05 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:36:20 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:36:20 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:36:31 --> Severity: Notice --> Undefined variable: data /home/servic/public_html/tutorias/application/modules/tutorias/controllers/Tutorias.php 531
ERROR - 2019-04-21 22:36:31 --> Severity: Notice --> Undefined variable: data /home/servic/public_html/tutorias/application/modules/tutorias/controllers/Tutorias.php 532
ERROR - 2019-04-21 22:36:31 --> Severity: Notice --> Undefined variable: motivoCancelacionId /home/servic/public_html/tutorias/application/modules/tutorias/views/cancelar_modal.php 19
ERROR - 2019-04-21 22:36:55 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:36:55 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:37:23 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 22:37:24 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:37:24 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:37:32 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:37:32 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:37:42 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:37:42 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:37:46 --> Severity: Notice --> Undefined variable: data /home/servic/public_html/tutorias/application/modules/tutorias/controllers/Tutorias.php 531
ERROR - 2019-04-21 22:37:46 --> Severity: Notice --> Undefined variable: data /home/servic/public_html/tutorias/application/modules/tutorias/controllers/Tutorias.php 532
ERROR - 2019-04-21 22:37:46 --> Severity: Notice --> Undefined variable: motivoCancelacionId /home/servic/public_html/tutorias/application/modules/tutorias/views/cancelar_modal.php 19
ERROR - 2019-04-21 22:40:15 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 22:40:16 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:40:16 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:40:28 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:40:28 --> 404 Page Not Found: /index
ERROR - 2019-04-21 22:40:39 --> Severity: Notice --> Undefined variable: data /home/servic/public_html/tutorias/application/modules/tutorias/controllers/Tutorias.php 531
ERROR - 2019-04-21 22:40:39 --> Severity: Notice --> Undefined variable: data /home/servic/public_html/tutorias/application/modules/tutorias/controllers/Tutorias.php 532
ERROR - 2019-04-21 22:40:39 --> Severity: Notice --> Undefined variable: motivoCancelacionId /home/servic/public_html/tutorias/application/modules/tutorias/views/cancelar_modal.php 18
ERROR - 2019-04-21 22:54:29 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-21 22:54:31 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 22:54:31 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 22:54:32 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
ERROR - 2019-04-21 22:54:32 --> 404 Page Not Found: ../modules/estudiante/controllers/Estudiante/vendor
