<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-05 09:49:09 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-05 10:33:41 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-05 10:49:31 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-05 10:50:12 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-05 10:52:28 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-05 14:40:49 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-05 15:11:42 --> 404 Page Not Found: /index
ERROR - 2019-04-05 15:11:55 --> 404 Page Not Found: /index
ERROR - 2019-04-05 15:12:30 --> 404 Page Not Found: /index
ERROR - 2019-04-05 15:13:37 --> 404 Page Not Found: /index
ERROR - 2019-04-05 15:14:48 --> 404 Page Not Found: /index
ERROR - 2019-04-05 15:51:55 --> 404 Page Not Found: /index
