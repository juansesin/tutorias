<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-03 06:18:47 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-03 06:19:33 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-03 06:44:00 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-03 07:59:36 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-03 14:57:30 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 15:22:40 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 15:23:13 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\Login_model.php 39
ERROR - 2019-04-03 15:56:17 --> Severity: 8192 --> strpos(): Non-string needles will be interpreted as strings in the future. Use an explicit chr() call to preserve the current behavior C:\xampp7\htdocs\tutorias\application\third_party\MX\Router.php 239
ERROR - 2019-04-03 15:56:20 --> Severity: 8192 --> strpos(): Non-string needles will be interpreted as strings in the future. Use an explicit chr() call to preserve the current behavior C:\xampp7\htdocs\tutorias\application\third_party\MX\Router.php 239
ERROR - 2019-04-03 15:56:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp7\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 15:56:22 --> Severity: 8192 --> strpos(): Non-string needles will be interpreted as strings in the future. Use an explicit chr() call to preserve the current behavior C:\xampp7\htdocs\tutorias\application\third_party\MX\Router.php 239
ERROR - 2019-04-03 15:56:29 --> Severity: 8192 --> strpos(): Non-string needles will be interpreted as strings in the future. Use an explicit chr() call to preserve the current behavior C:\xampp7\htdocs\tutorias\application\third_party\MX\Router.php 239
ERROR - 2019-04-03 15:56:31 --> Severity: 8192 --> strpos(): Non-string needles will be interpreted as strings in the future. Use an explicit chr() call to preserve the current behavior C:\xampp7\htdocs\tutorias\application\third_party\MX\Router.php 239
ERROR - 2019-04-03 15:56:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp7\htdocs\tutorias\application\hooks\Home.php 58
ERROR - 2019-04-03 15:56:34 --> Severity: 8192 --> strpos(): Non-string needles will be interpreted as strings in the future. Use an explicit chr() call to preserve the current behavior C:\xampp7\htdocs\tutorias\application\third_party\MX\Router.php 239
ERROR - 2019-04-03 15:56:39 --> Severity: 8192 --> strpos(): Non-string needles will be interpreted as strings in the future. Use an explicit chr() call to preserve the current behavior C:\xampp7\htdocs\tutorias\application\third_party\MX\Router.php 239
