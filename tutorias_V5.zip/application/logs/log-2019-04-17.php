<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-17 08:05:15 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-17 10:00:06 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-17 15:58:11 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-17 16:33:44 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-17 16:34:02 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-17 16:34:18 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-17 16:56:12 --> Severity: Notice --> Undefined variable: ASIGNATURA /home/servic/public_html/tutorias/application/modules/estudiante/views/form_busqueda.php 121
ERROR - 2019-04-17 16:56:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/estudiante/views/form_busqueda.php 121
ERROR - 2019-04-17 16:56:53 --> Severity: Notice --> Undefined variable: ASIGNATURA /home/servic/public_html/tutorias/application/modules/estudiante/views/form_busqueda.php 121
ERROR - 2019-04-17 16:56:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/estudiante/views/form_busqueda.php 121
ERROR - 2019-04-17 16:58:01 --> Severity: Notice --> Undefined variable: ASIGNATURAS /home/servic/public_html/tutorias/application/modules/estudiante/views/form_busqueda.php 121
ERROR - 2019-04-17 16:58:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/estudiante/views/form_busqueda.php 121
ERROR - 2019-04-17 17:03:27 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-17 17:04:17 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-17 17:16:28 --> Severity: Notice --> Undefined variable: ASIGNATURA /home/servic/public_html/tutorias/application/modules/estudiante/views/form_busqueda.php 121
ERROR - 2019-04-17 17:16:28 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/estudiante/views/form_busqueda.php 121
ERROR - 2019-04-17 17:54:13 --> Severity: Notice --> Undefined variable: ASIGNATURA /home/servic/public_html/tutorias/application/modules/estudiante/views/form_busqueda.php 119
ERROR - 2019-04-17 17:54:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/estudiante/views/form_busqueda.php 119
ERROR - 2019-04-17 17:55:42 --> Severity: Notice --> Undefined variable: ASIGNATURAS /home/servic/public_html/tutorias/application/modules/estudiante/views/form_busqueda.php 119
ERROR - 2019-04-17 17:55:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/estudiante/views/form_busqueda.php 119
ERROR - 2019-04-17 17:58:03 --> Severity: Notice --> Undefined variable: ASIGNATURA /home/servic/public_html/tutorias/application/modules/estudiante/views/form_busqueda.php 119
ERROR - 2019-04-17 17:58:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/servic/public_html/tutorias/application/modules/estudiante/views/form_busqueda.php 119
