<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-16 10:53:11 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
ERROR - 2019-04-16 11:31:14 --> Severity: Notice --> Undefined property: stdClass::$photo /home/servic/public_html/tutorias/application/modules/login/models/Login_model.php 39
