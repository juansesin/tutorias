<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-12 09:33:59 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:33:59 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:33:59 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:33:59 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:33:59 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:33:59 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:33:59 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:33:59 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:33:59 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:33:59 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:33:59 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:33:59 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:33:59 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:33:59 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:33:59 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:33:59 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:33:59 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:33:59 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:33:59 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:33:59 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:33:59 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:33:59 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:33:59 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:33:59 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:33:59 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:33:59 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:33:59 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:33:59 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:33:59 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:33:59 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:33:59 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:33:59 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:33:59 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:34:00 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:34:00 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:34:00 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:34:00 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:34:00 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:34:00 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:34:00 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:34:00 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:34:00 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:34:00 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:34:00 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:34:00 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:34:00 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:46:39 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:46:39 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:46:39 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:46:55 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:47:40 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:47:49 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:48:39 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:48:40 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:48:40 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:48:40 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:48:40 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:48:40 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:48:40 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:48:40 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:48:43 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:48:43 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:48:43 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:48:45 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:48:45 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:48:45 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:48:45 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:48:45 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:48:45 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:48:46 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:48:46 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:48:46 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:48:54 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:48:54 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:48:54 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:49:34 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:49:34 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:49:34 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:49:42 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:49:42 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:49:42 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:52:19 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:52:19 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:52:22 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:52:22 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:55:07 --> 404 Page Not Found: /index
ERROR - 2019-03-12 09:55:07 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:06:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\tutorias\application\views\layout.php 510
ERROR - 2019-03-12 10:06:00 --> Severity: Notice --> Undefined variable: enlacesManuales C:\xampp\htdocs\tutorias\application\views\template\menu.php 184
ERROR - 2019-03-12 10:06:00 --> Severity: Notice --> Undefined variable: enlacesVideos C:\xampp\htdocs\tutorias\application\views\template\menu.php 199
ERROR - 2019-03-12 10:06:00 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:06:00 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:06:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\tutorias\application\views\layout.php 510
ERROR - 2019-03-12 10:06:04 --> Severity: Notice --> Undefined variable: enlacesManuales C:\xampp\htdocs\tutorias\application\views\template\menu.php 184
ERROR - 2019-03-12 10:06:04 --> Severity: Notice --> Undefined variable: enlacesVideos C:\xampp\htdocs\tutorias\application\views\template\menu.php 199
ERROR - 2019-03-12 10:06:04 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:06:04 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:06:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\tutorias\application\views\layout.php 510
ERROR - 2019-03-12 10:06:08 --> Severity: Notice --> Undefined variable: enlacesManuales C:\xampp\htdocs\tutorias\application\views\template\menu.php 184
ERROR - 2019-03-12 10:06:08 --> Severity: Notice --> Undefined variable: enlacesVideos C:\xampp\htdocs\tutorias\application\views\template\menu.php 199
ERROR - 2019-03-12 10:06:09 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:06:09 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:06:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\tutorias\application\views\layout.php 510
ERROR - 2019-03-12 10:06:12 --> Severity: Notice --> Undefined variable: enlacesManuales C:\xampp\htdocs\tutorias\application\views\template\menu.php 184
ERROR - 2019-03-12 10:06:12 --> Severity: Notice --> Undefined variable: enlacesVideos C:\xampp\htdocs\tutorias\application\views\template\menu.php 199
ERROR - 2019-03-12 10:06:12 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:06:12 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:06:41 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:06:41 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:08:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\tutorias\application\views\layout.php 44
ERROR - 2019-03-12 10:08:32 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:08:32 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:08:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\tutorias\application\views\layout.php 44
ERROR - 2019-03-12 10:08:34 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:08:34 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:08:36 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\tutorias\application\views\layout.php 44
ERROR - 2019-03-12 10:08:36 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:08:36 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:09:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\tutorias\application\views\layout.php 44
ERROR - 2019-03-12 10:09:07 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:09:07 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:10:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\tutorias\application\views\layout.php 309
ERROR - 2019-03-12 10:10:02 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:10:03 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:11:16 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:11:16 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:11:46 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:11:46 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:12:53 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:12:53 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:13:34 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:13:34 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:14:14 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:14:14 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:14:20 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:14:20 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:15:55 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:15:55 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:16:03 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:16:03 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:16:21 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:16:21 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:17:11 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:17:11 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:21:08 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:21:08 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:21:38 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:21:38 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:21:39 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:21:39 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:21:49 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:21:49 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:22:19 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:22:23 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:22:23 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:23:44 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:23:45 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:24:17 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:24:17 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:52:23 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:52:23 --> 404 Page Not Found: /index
ERROR - 2019-03-12 10:52:28 --> Query error: Table 'vci_app.param_lugares' doesn't exist - Invalid query: SELECT *
FROM `param_lugares`
ORDER BY `sede` ASC
ERROR - 2019-03-12 10:52:28 --> Severity: Error --> Call to a member function num_rows() on boolean C:\xampp\htdocs\tutorias\application\models\General_model.php 24
ERROR - 2019-03-12 10:53:08 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 10:53:08 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 10:55:47 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 10:55:47 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 10:59:31 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 10:59:31 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 10:59:32 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 10:59:32 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 10:59:33 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 10:59:33 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 10:59:33 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 10:59:33 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 10:59:34 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 10:59:34 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 10:59:35 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 10:59:35 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:01:16 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:01:16 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:01:18 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:01:18 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:01:34 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:01:34 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:01:35 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:01:35 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:01:35 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:01:35 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:01:52 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:01:52 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:04:28 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:04:28 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:13:37 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:13:37 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:15:40 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:15:40 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:16:02 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:16:02 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:17:44 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:17:44 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:19:17 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:19:17 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:21:40 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:21:40 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:21:56 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:21:56 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:22:16 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:22:16 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:22:37 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:22:37 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:22:46 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:22:46 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:22:51 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:22:51 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:23:02 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:23:02 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:23:14 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:23:14 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:23:24 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:23:24 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:24:33 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:24:33 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:25:55 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:25:55 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:25:55 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:27:50 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:27:50 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:27:50 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:27:50 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:52:20 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:52:20 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:57:23 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:57:23 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:57:23 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:57:23 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:59:36 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:59:36 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:59:36 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:59:51 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:59:51 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 11:59:52 --> Query error: Table 'tutorias.task' doesn't exist - Invalid query: SELECT count(id_task) CONTEO FROM task WHERE fk_id_operation = 1 AND start >= '2019-01-01'
ERROR - 2019-03-12 11:59:52 --> Severity: Error --> Call to a member function row() on boolean C:\xampp\htdocs\tutorias\application\models\General_model.php 85
ERROR - 2019-03-12 11:59:55 --> Query error: Table 'tutorias.task' doesn't exist - Invalid query: SELECT count(id_task) CONTEO FROM task WHERE fk_id_operation = 1 AND start >= '2019-01-01'
ERROR - 2019-03-12 11:59:55 --> Severity: Error --> Call to a member function row() on boolean C:\xampp\htdocs\tutorias\application\models\General_model.php 85
ERROR - 2019-03-12 11:59:57 --> Query error: Table 'tutorias.task' doesn't exist - Invalid query: SELECT count(id_task) CONTEO FROM task WHERE fk_id_operation = 1 AND start >= '2019-01-01'
ERROR - 2019-03-12 11:59:57 --> Severity: Error --> Call to a member function row() on boolean C:\xampp\htdocs\tutorias\application\models\General_model.php 85
ERROR - 2019-03-12 11:59:57 --> Query error: Table 'tutorias.task' doesn't exist - Invalid query: SELECT count(id_task) CONTEO FROM task WHERE fk_id_operation = 1 AND start >= '2019-01-01'
ERROR - 2019-03-12 11:59:57 --> Severity: Error --> Call to a member function row() on boolean C:\xampp\htdocs\tutorias\application\models\General_model.php 85
ERROR - 2019-03-12 12:04:25 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:04:25 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:04:25 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:04:25 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:04:33 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:04:33 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:04:33 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:04:33 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:05:43 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:05:43 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:05:43 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:05:43 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:10:49 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:10:49 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:11:05 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:11:05 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:11:05 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:20:50 --> Severity: error --> Exception: Unable to locate the model you have specified: Admin_model C:\xampp\htdocs\tutorias\system\core\Loader.php 344
ERROR - 2019-03-12 12:21:13 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:21:13 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:21:48 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:21:48 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:23:27 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:23:27 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:23:28 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:23:28 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:23:42 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:23:42 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:23:43 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:23:43 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:24:09 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:24:09 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:24:23 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:24:23 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:25:07 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:25:07 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:25:07 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:25:11 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:25:11 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:26:02 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:26:02 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:26:15 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:26:15 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:26:15 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:27:46 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:27:46 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:27:46 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:27:49 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/undefined
ERROR - 2019-03-12 12:28:30 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:28:30 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:28:31 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:28:31 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:28:33 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/undefinedparametros
ERROR - 2019-03-12 12:29:37 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:29:37 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:30:23 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:30:23 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:32:05 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:32:05 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:32:05 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:32:40 --> Severity: Notice --> Undefined property: Parametros::$admin_model C:\xampp\htdocs\tutorias\application\modules\parametros\controllers\Parametros.php 74
ERROR - 2019-03-12 12:32:40 --> Severity: Error --> Call to a member function saveLugar() on null C:\xampp\htdocs\tutorias\application\modules\parametros\controllers\Parametros.php 74
ERROR - 2019-03-12 12:32:46 --> Severity: Notice --> Undefined property: Parametros::$admin_model C:\xampp\htdocs\tutorias\application\modules\parametros\controllers\Parametros.php 74
ERROR - 2019-03-12 12:32:46 --> Severity: Error --> Call to a member function saveLugar() on null C:\xampp\htdocs\tutorias\application\modules\parametros\controllers\Parametros.php 74
ERROR - 2019-03-12 12:33:26 --> Severity: Notice --> Undefined index: id_material C:\xampp\htdocs\tutorias\application\modules\parametros\views\lugares.php 90
ERROR - 2019-03-12 12:33:27 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:33:27 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:34:21 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:34:21 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:34:21 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:34:49 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:34:49 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:34:49 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:35:14 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:35:14 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:35:46 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:35:46 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/dist
ERROR - 2019-03-12 12:41:46 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\login_model.php 39
ERROR - 2019-03-12 12:41:46 --> Query error: Table 'tutorias.task' doesn't exist - Invalid query: SELECT count(id_task) CONTEO FROM task WHERE fk_id_operation = 1 AND start >= '2019-01-01'
ERROR - 2019-03-12 12:41:46 --> Severity: Error --> Call to a member function row() on boolean C:\xampp\htdocs\tutorias\application\models\General_model.php 85
ERROR - 2019-03-12 13:27:11 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/cargarModalAsignatura
ERROR - 2019-03-12 13:27:24 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/cargarModalAsignatura
ERROR - 2019-03-12 13:32:13 --> Query error: Unknown column 'programas' in 'order clause' - Invalid query: SELECT *
FROM `param_programas`
ORDER BY `programas` ASC
ERROR - 2019-03-12 13:32:13 --> Severity: Error --> Call to a member function num_rows() on boolean C:\xampp\htdocs\tutorias\application\models\General_model.php 24
ERROR - 2019-03-12 13:32:21 --> Query error: Unknown column 'programas' in 'order clause' - Invalid query: SELECT *
FROM `param_programas`
ORDER BY `programas` ASC
ERROR - 2019-03-12 13:32:21 --> Severity: Error --> Call to a member function num_rows() on boolean C:\xampp\htdocs\tutorias\application\models\General_model.php 24
ERROR - 2019-03-12 13:32:57 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\tutorias\application\modules\parametros\views\asignaturas_modal.php 20
ERROR - 2019-03-12 13:32:57 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\tutorias\application\modules\parametros\views\asignaturas_modal.php 20
ERROR - 2019-03-12 13:32:57 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\tutorias\application\modules\parametros\views\asignaturas_modal.php 20
ERROR - 2019-03-12 13:32:57 --> Severity: Notice --> Undefined variable: company C:\xampp\htdocs\tutorias\application\modules\parametros\views\asignaturas_modal.php 20
ERROR - 2019-03-12 13:34:13 --> Severity: Notice --> Undefined index: id_company C:\xampp\htdocs\tutorias\application\modules\parametros\views\asignaturas_modal.php 20
ERROR - 2019-03-12 13:34:13 --> Severity: Notice --> Undefined index: id_company C:\xampp\htdocs\tutorias\application\modules\parametros\views\asignaturas_modal.php 20
ERROR - 2019-03-12 13:35:13 --> Severity: Error --> Call to undefined method Parametros_model::saveAsignatura() C:\xampp\htdocs\tutorias\application\modules\parametros\controllers\Parametros.php 233
ERROR - 2019-03-12 13:35:22 --> Severity: Error --> Call to undefined method Parametros_model::saveAsignatura() C:\xampp\htdocs\tutorias\application\modules\parametros\controllers\Parametros.php 233
ERROR - 2019-03-12 13:37:18 --> Query error: Unknown column 'programa' in 'field list' - Invalid query: INSERT INTO `param_asignaturas` (`programa`, `asignatura`) VALUES ('1', 'Finanzas')
ERROR - 2019-03-12 13:38:43 --> Query error: Unknown column 'programa' in 'field list' - Invalid query: INSERT INTO `param_asignaturas` (`programa`, `asignatura`) VALUES ('1', 'Fisio')
ERROR - 2019-03-12 13:52:54 --> Query error: Unknown column 'programa' in 'field list' - Invalid query: INSERT INTO `param_asignaturas` (`programa`, `asignatura`) VALUES ('1', 'Fisio')
ERROR - 2019-03-12 13:56:24 --> Query error: Unknown column 'asignatura' in 'field list' - Invalid query: INSERT INTO `param_asignaturas` (`fk_id_param_programas`, `asignatura`) VALUES ('1', 'Fisio')
ERROR - 2019-03-12 13:56:38 --> Query error: Unknown column 'asignatura' in 'field list' - Invalid query: INSERT INTO `param_asignaturas` (`fk_id_param_programas`, `asignatura`) VALUES ('1', 'Fisio')
ERROR - 2019-03-12 17:52:24 --> Severity: Notice --> Undefined property: stdClass::$photo C:\xampp\htdocs\tutorias\application\modules\login\models\login_model.php 39
ERROR - 2019-03-12 17:53:18 --> Query error: Unknown column 'asignatura' in 'field list' - Invalid query: INSERT INTO `param_asignaturas` (`fk_id_param_programas`, `asignatura`) VALUES ('1', 'Nueva')
ERROR - 2019-03-12 17:54:51 --> Severity: Notice --> Undefined index: programa C:\xampp\htdocs\tutorias\application\modules\parametros\views\asignaturas.php 95
ERROR - 2019-03-12 17:54:51 --> Severity: Notice --> Undefined index: asignatura C:\xampp\htdocs\tutorias\application\modules\parametros\views\asignaturas.php 96
ERROR - 2019-03-12 18:02:22 --> Severity: Notice --> Undefined index: asignatura C:\xampp\htdocs\tutorias\application\modules\parametros\views\asignaturas.php 96
ERROR - 2019-03-12 18:03:38 --> Severity: Notice --> Undefined index: asignatura C:\xampp\htdocs\tutorias\application\modules\parametros\views\asignaturas_modal.php 31
ERROR - 2019-03-12 18:06:21 --> 404 Page Not Found: ../modules/parametros/controllers/Parametros/index2.html
ERROR - 2019-03-12 18:47:20 --> Query error: Unknown column 'A.id_param_temas' in 'where clause' - Invalid query: SELECT *
FROM `param_temas` `T`
INNER JOIN `param_asignaturas` `A` ON `A`.`id_param_asignaturas` = `T`.`fk_id_param_asignaturas`
WHERE `A`.`id_param_temas` = '1'
ORDER BY `A`.`asignaturas` ASC
ERROR - 2019-03-12 18:47:20 --> Severity: Error --> Call to a member function num_rows() on boolean C:\xampp\htdocs\tutorias\application\models\General_model.php 71
ERROR - 2019-03-12 18:47:30 --> Query error: Unknown column 'A.id_param_temas' in 'where clause' - Invalid query: SELECT *
FROM `param_temas` `T`
INNER JOIN `param_asignaturas` `A` ON `A`.`id_param_asignaturas` = `T`.`fk_id_param_asignaturas`
WHERE `A`.`id_param_temas` = '1'
ORDER BY `A`.`asignaturas` ASC
ERROR - 2019-03-12 18:47:30 --> Severity: Error --> Call to a member function num_rows() on boolean C:\xampp\htdocs\tutorias\application\models\General_model.php 71
ERROR - 2019-03-12 18:50:11 --> Severity: Notice --> Undefined index: tema C:\xampp\htdocs\tutorias\application\modules\parametros\views\temas_modal.php 31
ERROR - 2019-03-12 18:50:49 --> Severity: Notice --> Undefined index: tema C:\xampp\htdocs\tutorias\application\modules\parametros\views\temas_modal.php 31
ERROR - 2019-03-12 23:22:54 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'root'@'localhost' (using password: NO) /home/bmottag/public_html/tutorias/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2019-03-12 23:22:54 --> Unable to connect to the database
ERROR - 2019-03-12 23:22:54 --> Severity: error --> Exception: Unable to locate the model you have specified: Login_model /home/bmottag/public_html/tutorias/system/core/Loader.php 344
ERROR - 2019-03-12 23:24:25 --> Severity: error --> Exception: Unable to locate the model you have specified: Login_model /home/bmottag/public_html/tutorias/system/core/Loader.php 344
ERROR - 2019-03-12 23:25:40 --> Severity: Notice --> Undefined property: stdClass::$photo /home/bmottag/public_html/tutorias/application/modules/login/models/Login_model.php 39
